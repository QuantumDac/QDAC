# DAG consensus logic

# TODO: implement IOTA-style tip selection
