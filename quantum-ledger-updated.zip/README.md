# Quantum Ledger (Python/QRL Fork)

**Local Development**

> **Verify Python version:**
> ```bash
> python3 --version
> ```

> **If `python3 --version` still shows 3.8:**
> - Check the new binary directly:
>   ```bash
>   python3.10 --version
>   ```
> - To update the system `python3` alternative:
>   ```bash
>   sudo update-alternatives --install /usr/bin/python3 python3 /usr/bin/python3.10 1
>   sudo update-alternatives --config python3
>   ```
> - Or create a shell alias:
>   ```bash
>   echo "alias python3=python3.10" >> ~/.bashrc
>   source ~/.bashrc
>   ```

> **If Python < 3.9, update to Python 3.10:**
> ```bash
> sudo apt-get update
> sudo apt-get install -y software-properties-common
> sudo add-apt-repository ppa:deadsnakes/ppa
> sudo apt-get update
> sudo apt-get install -y python3.10 python3.10-venv python3.10-dev
> ```

> **Install build tools and venv support:**
> ```bash
> sudo apt-get install -y build-essential python3-dev python3.10-venv libffi-dev
> ```

> **Troubleshooting `apt-get update` hanging:**
> ```bash
> sudo killall apt apt-get
> sudo rm /var/lib/apt/lists/lock /var/cache/apt/archives/lock
> ps aux | grep -E "apt|dpkg"
> sudo kill <pid>
> sudo dpkg --configure -a
> sudo apt-get install -f
> sudo rm -rf /var/lib/apt/lists/*
> sudo apt-get update
> sudo sed -i 's|http://.*.ubuntu.com|http://mirror.math.princeton.edu/pub/ubuntu|g' /etc/apt/sources.list
> sudo apt-get -o Acquire::ForceIPv4=true update
> wsl --shutdown
> ```

**Setup Steps:**

1. Clone repo and enter directory:
   ```bash
   git clone <your-repo-url> quantum-ledger
   cd quantum-ledger
   ```
2. Install system build tools (prerequisite):
   - **Debian/Ubuntu:**
     ```bash
     sudo apt-get update &&          sudo apt-get install -y build-essential python3-dev python3-venv libffi-dev
     ```
     _If you receive a "ensurepip is not available" error when creating a venv, run:_
     ```bash
     sudo apt-get install python3-venv
     ```
   - **Windows:** Install the Build Tools for Visual Studio (select C++ build tools).
3. Create virtualenv & install dependencies:
   ```bash
   python3 -m venv venv
   source venv/bin/activate  # On Windows use `venv\Scriptsctivate`
   pip install -r requirements.txt
   ```
4. Start node via Docker Compose:
   ```bash
   docker-compose up --build
   ```
