# Storage & pruning logic

# TODO: implement ChainCrunch snapshotter
